<footer class="main-footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-6">
                <p> &copy; {{ config('app.name') }} - {{ date('Y') }}</p>
            </div>
            <div class="col-sm-6 text-right">
                <p>Design by <a href="#" class="external">Ivan Santos</a></p>
            </div>
        </div>
    </div>
</footer>
